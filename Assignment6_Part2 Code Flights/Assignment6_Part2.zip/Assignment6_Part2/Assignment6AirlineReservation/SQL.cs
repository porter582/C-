﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace Assignment6AirlineReservation
{
    class SQL
    {
        public clsDataAccess db = new clsDataAccess();
        DataSet ds = new DataSet();
        public int NumRows = 0;

        public DataSet getFlights()
        {
            //DataSet ds = new DataSet();
            ////Should probably not have SQL statements behind the UI
            //string sSQL = "SELECT Flight_ID, Flight_Number, Aircraft_Type FROM FLIGHT";
            //int iRet = 0;
            //ds = sSQL;

            ds = db.ExecuteSQLStatement("SELECT Flight_ID, Flight_Number, Aircraft_Type FROM flight", ref NumRows);
            return ds;
        }

        public DataSet getPassengers(int index)
        {
            ds = db.ExecuteSQLStatement("SELECT * FROM passenger p INNER JOIN flight_passenger_link fpl ON fpl.passenger_id = p.passenger_id WHERE fpl.flight_id = " + (index + 1), ref NumRows);
            return ds;
        }

        public void addPassenger(string firstName, string lastName, int index)
        {
            ds = db.ExecuteSQLStatement("SELECT MAX(passenger_id) + 1 FROM passenger", ref NumRows);
            string newId = ds.Tables[0].Rows[0][0].ToString();

            index = index + 1;
            db.ExecuteSQLStatement("INSERT INTO Passenger (Passenger_id, First_Name, Last_Name) VALUES ('" + newId + "', '" + firstName + "', '" + lastName + "')", ref NumRows);
            db.ExecuteSQLStatement("INSERT INTO flight_passenger_link (Flight_id, Passenger_id) VALUES ('" + index + "', '" + newId + "')", ref NumRows);

        }

        public void deletePassenger(string passId)
        {
            db.ExecuteSQLStatement("Delete FROM Flight_Passenger_Link WHERE PASSENGER_ID = " + passId, ref NumRows);
            db.ExecuteSQLStatement("Delete FROM PASSENGER WHERE PASSENGER_ID = " + passId, ref NumRows);
        }

    }
}
