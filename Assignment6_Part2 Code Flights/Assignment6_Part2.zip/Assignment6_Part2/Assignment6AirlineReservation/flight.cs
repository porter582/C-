﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace Assignment6AirlineReservation
{
    class flight
    {
        /// <summary>
        /// ds is the data set that will
        /// be loaded with our database after 
        /// the sql statements are executed
        /// </summary>
        //public DataSet ds = new DataSet();

        /// <summary>
        /// sql is the object for the sql
        /// class that will hold all of the 
        /// sql queries
        /// </summary>
        //public SQL sql = new SQL();

        public string flight_id;
        public string flight_num;
        public string aircraft_type;

        public string firstName;
        public string lastName;
        public string passId;

        public flight()
        {
            //ds = sql.getFlights();
        }

        public List<flight> loadFlights()
        {
            List<flight> flightObj = new List<flight>();
            DataSet ds = new DataSet();
            SQL sql = new SQL();
            ds = sql.getFlights();

            for (int i = 0; i < sql.NumRows; i++)
            {
                flightObj.Add(new flight{ flight_id = ds.Tables[0].Rows[i][0].ToString(),
                    flight_num = ds.Tables[0].Rows[i][1].ToString(),
                    aircraft_type = ds.Tables[0].Rows[i][2].ToString() });
            }
            return flightObj;
        }

        public List<flight> loadPass(int index)
        {
            List<flight> passObj = new List<flight>();
            DataSet ds = new DataSet();
            SQL sql = new SQL();
            ds = sql.getPassengers(index);

            for (int i = 0; i < sql.NumRows; i++)
            {
                passObj.Add(new flight
                {
                    passId = ds.Tables[0].Rows[i][0].ToString(),
                    firstName = ds.Tables[0].Rows[i][1].ToString(),
                    lastName = ds.Tables[0].Rows[i][2].ToString()
                });
            }
            return passObj;
        }

        public void addPassenger(string firstName, string lastName, int index)
        {
            SQL sql = new SQL();
            sql.addPassenger(firstName, lastName, index);
        }

        public void deletePassenger(string passId)
        {
            SQL sql = new SQL();
            sql.deletePassenger(passId);
        }
    }
}
